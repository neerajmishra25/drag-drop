const ListItemTypes = {
    CARD: 'list',
  }
  export default ListItemTypes