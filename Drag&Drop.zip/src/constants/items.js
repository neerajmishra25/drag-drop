 const ItemTypes = {
    CARD: 'card',
  }
  export default ItemTypes