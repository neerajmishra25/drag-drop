import TabOption from "./TabOption";
const { IST_TAB, SECOND_TAB, THIRD_TAB, FOURTH_TAB } = TabOption;
const dragableItem = [
  {
    id: "div1",
    name: "Hey",
    tab: IST_TAB,
  },
  {
    id: "div2",
    name: "Hey Tab 1",
    tab: IST_TAB,
  },
  {
    id: "div3",
    name: "Tab 1 Item",
    tab: IST_TAB,
  },
  {
    id: "div4",
    name: "There",
    tab: SECOND_TAB,
  },
  {
    id: "div5",
    name: "There asdlf",
    tab: SECOND_TAB,
  },
  {
    id: "div6",
    name: "How are you? sldfk",
    tab: THIRD_TAB,
  },
  {
    id: "div7",
    name: "How are you? sldfjsd",
    tab: THIRD_TAB,
  },
];

export default dragableItem;
