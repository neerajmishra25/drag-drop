const TabOption = {
  IST_TAB: "IST_TAB",
  SECOND_TAB: "SECOND_TAB",
  THIRD_TAB: "third_tab",
  FOURTH_TAB: "fourth_tab",
};

export default TabOption;
