import { useState, useCallback } from "react";
import DragContainer from "./DragContainer";
import DropElem from "../component/DropElem";
import Tabs from "../component/Tabs.jsx/Tabs";
import TabOption from "../constants/TabOption";
import Card from "../component/Card";
import update from "immutability-helper";
function DropContainer() {
  const [displayedItem, setDisplayedItem] = useState(TabOption.IST_TAB);
  const [cards, setCards] = useState([
    {
      id: 1,
    },
    {
      id: 2,
    },
  ]);
  const moveCard = useCallback(
    (dragIndex, hoverIndex) => {
      const dragCard = cards[dragIndex];
      setCards(
        update(cards, {
          $splice: [
            [dragIndex, 1],
            [hoverIndex, 0, dragCard],
          ],
        })
      );
    },
    [cards]
  );
  const renderCard = (card, index) => {
    return (
      <Card key={card.id} index={index} id={card.id} moveCard={moveCard} />
    );
  };
  //   const [tabs] = useState({ist_tab:"ist_tab", "second_tab", "third_tab", "fourth_tab"});

  return (
    <>
      <Tabs
        displayedItem={displayedItem}
        changeTab={setDisplayedItem}
        tabs={[
          { displayName: "Ist Tab", address: TabOption.IST_TAB },
          { displayName: "Second Tab", address: TabOption.SECOND_TAB },
          { displayName: "Third Tab", address: TabOption.THIRD_TAB },
          { displayName: "Fourth Tab", address: TabOption.FOURTH_TAB },
        ]}
      />
      <DragContainer displayedItem={displayedItem}></DragContainer>
      <div className="drop-container">
        <div style={{ width: "80%", display: "flex" }}>
          <p style={{ width: "25%" }}>Ist Tab</p>
          <p style={{ width: "25%" }}>Second Tab</p>
          <p style={{ width: "25%" }}>Third Tab</p>
          <p style={{ width: "25%" }}>Fourth Tab</p>
        </div>
        <div
          className="drop-zone"
          style={{
            width: "80%",
            height: "65%",
          }}
        >
          {cards.map((card, i) => renderCard(card, i))}
        </div>
      </div>
    </>
  );
}
export default DropContainer;
