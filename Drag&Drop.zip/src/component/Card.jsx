import React, { useCallback, useRef, useState } from "react";
import DropElem from "./DropElem";
import Tabs from "./Tabs.jsx/Tabs";
import TabOption from "../constants/TabOption";
import { useDrag } from "react-dnd";
import { useDrop } from "react-dnd";
import ItemTypes from "../constants/items";

const item = [
  {
    id: 1,
    backgroundColor: "red",
    accept: TabOption.IST_TAB,
  },
  {
    id: 2,

    backgroundColor: "yellow",
    accept: TabOption.SECOND_TAB,
  },
  {
    id: 3,
    backgroundColor: "green",
    accept: TabOption.THIRD_TAB,
  },
  {
    id: 4,
    backgroundColor: "black",
    accept: TabOption.FOURTH_TAB,
  },
];

const Card = ({ id, index, moveCard }) => {
  const [listItem, setlistItem] = useState(item);
  const [elemList, setElemList] = useState([]);
  // const [tabs] = useState({ist_tab:"ist_tab", "second_tab", "third_tab", "fourth_tab"});
  const ref = useRef(null);
  const [{ handlerId }, drop] = useDrop({
    accept: ItemTypes.CARD,
    collect(monitor) {
      return {
        handlerId: monitor.getHandlerId(),
      };
    },
    hover(item, monitor) {
      if (!ref.current) {
        return;
      }
      const dragIndex = item.index;
      const hoverIndex = index;
      if (dragIndex === hoverIndex) {
        return;
      }
      const hoverBoundingRect = ref.current?.getBoundingClientRect();

      const hoverMiddleY =
        (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;

      const clientOffset = monitor.getClientOffset();

      const hoverClientY = clientOffset.y - hoverBoundingRect.top;
      if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
        return;
      }

      if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
        return;
      }
      moveCard(dragIndex, hoverIndex);
      item.index = hoverIndex;
    },
  });
  const [{ isDragging }, drag] = useDrag({
    type: ItemTypes.CARD,
    item: () => {
      return { id, index };
    },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });
  const opacity = isDragging ? 0 : 1;
  drag(drop(ref));

  const moveListItem = useCallback(
    (dragIndex, hoverIndex) => {
      console.log("moveList");
      const dragItem = listItem[dragIndex];
      const hoverItem = listItem[hoverIndex];
      // Swap places of dragItem and hoverItem in the listItem array
      setlistItem((listItem) => {
        const updatedlistItem = [...listItem];
        updatedlistItem[dragIndex] = hoverItem;
        updatedlistItem[hoverIndex] = dragItem;
        return updatedlistItem;
      });
    },
    [listItem]
  );
  return (
    <div
      className="dropped-row"
      style={{
        width: "80%",
        display: "flex",
        height: "40%",
        margin: "15px 0",
        opacity,
      }}
      ref={ref}
      data-handler-id={handlerId}
    >
      {listItem.map((item, index) => (
        <DropElem
          key={item.id}
          id={item.id}
          index={index}
          accept={item.accept}
          moveListItem={moveListItem}
          elemList={elemList}
          setElemList={setElemList}
        >
          {item.id}
        </DropElem>
      ))}
    </div>
  );
};

export default Card;
