import React from "react";
import PropTypes from "prop-types";
// import classnames from "classnames";

const Tabs = (props) => {
  const { tabs, changeTab, displayedItem } = props;

  const isActive = (itemName) => {
    return displayedItem === itemName;
  };

  return (
    <ul className="nav nav-tabs">
      {tabs.map((item, index) => (
        <li key={`nav-item-${index}`} className="nav-item">
          <button
            type="button"
            // className={classnames("nav-link like-link-button", {
            //   active: isActive(item.address),
            // })}
            onClick={(e) => changeTab(item.address)}
          >
            {item.displayName}
          </button>
        </li>
      ))}
    </ul>
  );
};

Tabs.propTypes = {
  tabs: PropTypes.array.isRequired,
  changeTab: PropTypes.func.isRequired,
  displayedItem: PropTypes.string.isRequired,
};

export default Tabs;
