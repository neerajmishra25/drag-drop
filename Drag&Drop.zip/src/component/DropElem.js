import React, { useRef, useState, useCallback, useEffect } from "react";
import { useDrag, useDrop, useDragDropManager } from "react-dnd";
import ListItemTypes from "../constants/listItems";
import dragableItem from "../constants/dragableItems";
import DragElem from "./DragElem";
import ItemTypes from "../constants/items";

const DropElem = ({ id, text, index, moveListItem, accept, elemList }) => {
  const [board, setBoard] = useState();
  // const dragDropManager = useDragDropManager();
  let counter = 0;

  // const [{ isDragging }, dragRef] = useDrag({
  //   type: ListItemTypes.CARD,
  //   item: { index },
  //   collect: (monitor) => ({
  //     isDragging: monitor.isDragging(),
  //   }),
  // });
  const [{ isOver, canDrop }, drop] = useDrop(() => ({
    accept: accept,
    drop: (item) => addImageToBoard(item.id, item.key),
    canDrop: (item, monitor) => check(),

    collect: (monitor) => ({
      isOver: monitor.isOver(),
      canDrop: monitor.canDrop(),
    }),
  }));
  const check = () => (counter > 0 ? false : true);
  //   useEffect(() => {
  //     console.log(canDrop);
  //   }, [isOver, board, canDrop]);
  const addImageToBoard = (id) => {
    const item = dragableItem.filter((item) => item.id === id);
    console.log(item[0], "dropped item");
    console.log(board, "boarding");
    counter++;
    setBoard(item[0]);
  };

  // const removeDropItem = useCallback(
  //   (id) => {
  //     console.log("removing drop item");
  //     const data = board.filter((d) => d.id !== id);
  //     setBoard(data);
  //   },
  //   [board]
  // );
  // const [spec, dropRef] = useDrop({
  //   accept: ListItemTypes.CARD,
  //   hover: (item, monitor) => {
  //     const dragIndex = item.index;
  //     const hoverIndex = index;
  //     const hoverBoundingRect = ref.current?.getBoundingClientRect();
  //     const hoverMiddleY =
  //       (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;
  //     const hoverActualY = monitor.getClientOffset().y - hoverBoundingRect.top;

  //     // if dragging down, continue only when hover is smaller than middle Y
  //     if (dragIndex < hoverIndex && hoverActualY < hoverMiddleY) return;
  //     // if dragging up, continue only when hover is bigger than middle Y
  //     if (dragIndex > hoverIndex && hoverActualY > hoverMiddleY) return;

  //     moveListItem(dragIndex, hoverIndex);
  //     item.index = hoverIndex;
  //   },
  // });

  // Join the 2 refs together into one (both draggable and can be dropped on)
  const ref = useRef(null);
  const dragDropRef = drop(ref);
  // const dragDropRef1=drag(drop(ref))

  // Make items being dragged transparent, so it's easier to see where we drop them
  // const opacity = isDragging ? 0 : 1;
  return (
    <div
      ref={dragDropRef}
      className="drop-sub-container"
      style={{ width: "25% ", height: "80%" }}
    >
      {board && (
        <DragElem
          key={1}
          type={accept}
          id={board.id}
          name={board.name}
          // removeDropItem={removeDropItem}
        ></DragElem>
      )}
    </div>
  );
};

export default DropElem;
