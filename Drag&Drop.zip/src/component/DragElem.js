import React from "react";
import { useDrag } from "react-dnd";
import ItemTypes from "../constants/items";

const DragElem = ({ id, name, removeDropItem, type }) => {
  const [{ isDragging }, drag] = useDrag({
    type: type,
    item: { id },

    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  });
  return (
    <div
      id={id}
      ref={drag}
      className="dargable-elem-1"
      style={{ backgroundColor: isDragging ? "#fbb" : "palegoldenrod" }}
    >
      {name}
    </div>
  );
};

export default DragElem;
